package Finally;

import java.io.IOException;

public class Employee {
	public void work() throws IOException {
		
	}
	public void work(String location) throws NullPointerException {
		
	}
}
